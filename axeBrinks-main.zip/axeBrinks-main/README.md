# axeBrinks
 
 
Preview : https://www.youtube.com/watch?v=_-Fxd5O_tzk
<p>
Download : https://discord.gg/5dev

Le script a été réalisé par @Amauu#0604 et je suis re passé derrière lui pour combler et "finir" le script, ceci n'est qu'une V.1, pas le temps de s'attarder dessus (pour le moment), si vous voulez rajouter des animations quelconques libres à vous, le code est libre d'accès. Revente et appropriation non autorisée.
